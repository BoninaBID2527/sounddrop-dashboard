SoundDrop - Dashboard vendite biglietti
=======================================

Report Power BI sulle vendite di biglietti di SoundDrop, piattaforma (di fantasia)
per concerti e festival in 12 città italiane. Periodo: gennaio 2025 - settembre 2026.
I dati sono di esempio.


CONTENUTO DELLA CARTELLA

  SoundDrop.pbip              progetto da aprire con Power BI Desktop
  SoundDrop.SemanticModel     modello dati (tabelle, query, relazioni, misure)
  SoundDrop.Report            report (pagine, grafici, tema)
  dati                        file CSV di origine


COME APRIRLO

  1. Aprire SoundDrop.pbip con Power BI Desktop.
  2. Home > Trasforma dati > Modifica parametri: in CartellaDati inserire il
     percorso della cartella "dati" (predefinito: C:\SoundDrop\dati).
  3. Applica modifiche / Aggiorna.


DATI

  Vendite.csv   un ordine per riga (data, evento, canale, quantità, prezzo, sconto)
  Eventi.csv    64 eventi (artista, genere, città, data, capienza, prezzo base)
  Citta.csv     12 città con regione e coordinate
  Canali.csv    App, Sito, Punto vendita, Partner

  Pulizia in Power Query:
  - rimozione delle righe duplicate
  - esclusione delle righe senza prezzo
  - conversione delle date scritte in due formati diversi (aaaa-mm-gg e gg/mm/aaaa)
  - normalizzazione dei generi (spazi e maiuscole)


MODELLO

  Schema a stella con Vendite come tabella dei fatti e le dimensioni Calendario,
  Eventi e Canali. Citta è collegata a Eventi. Relazioni uno-a-molti a direzione
  singola. Calendario è contrassegnata come tabella data.

  Misure principali: Incasso, Biglietti venduti, Prezzo medio biglietto,
  Tasso di riempimento, Incasso YTD, Incasso anno precedente,
  Variazione % vs anno precedente, Rank evento.


REPORT

  Panoramica         KPI, andamento mensile, generi, top 5 eventi, canali
  Città ed eventi    mappa, riempimento per città, classifica eventi
  Dettaglio evento   pagina di drill-through (clic destro su un evento)
